// src/domain/models/LoginRequest.ts

export interface LoginRequest {
  email: string;
  password: string;
}

// frontend-app/src/core/config/app.ts

export const AppConfig = {
  appVersion: '1.0.0',
  supportEmail: 'soporte@crowdknock.com',
  defaultLocale: 'es',
};
